TechMono dev assets
-------------------
fonts/                         TechMono Light, Regular, Oblique, Bold (.woff + .ttf)
techmono.css                   @font-face rules + terminal color tokens
tailwind.config.snippet.js     Tailwind v3 config and v4 @theme block

Quick start
1. Copy fonts/ and techmono.css into your prototype.
2. Import techmono.css, then use font-family: var(--font-techmono) or the Tailwind class font-techmono.

See LICENSE-NOTICE.txt for usage terms.
