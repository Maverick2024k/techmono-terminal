// ---------- Tailwind v3: tailwind.config.js ----------
module.exports = {
  theme: {
    extend: {
      fontFamily: {
        techmono: ['TechMono', 'ui-monospace', 'SFMono-Regular', 'Menlo', 'Consolas', 'monospace'],
      },
      colors: {
        term: {
          bg: '#06080b', panel: '#0b0f14', line: '#1b232d',
          text: '#cdd6e0', muted: '#7d8b9a',
          up: '#2ee6a6', down: '#ff5c74', warn: '#ffb547', accent: '#4cc9f0',
        },
      },
      fontSize: { term: ['13px', { lineHeight: '1.55' }] },
    },
  },
};

/* ---------- Tailwind v4: in your main CSS file ----------
@import "tailwindcss";
@theme {
  --font-techmono: "TechMono", ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  --color-term-bg: #06080b;   --color-term-panel: #0b0f14;  --color-term-line: #1b232d;
  --color-term-text: #cdd6e0; --color-term-muted: #7d8b9a;
  --color-term-up: #2ee6a6;   --color-term-down: #ff5c74;
  --color-term-warn: #ffb547; --color-term-accent: #4cc9f0;
}
Usage: <div class="font-techmono text-[13px] bg-term-bg text-term-text">0x71C7...976F</div>
*/
